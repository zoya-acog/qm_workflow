from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from shutil import copy2
from textwrap import dedent


class RunContext:
    """
    Represents a single workflow run.
    Owns the run directory and state.json.
    """

    def __init__(self, base_dir: Path, run_dir: Path | None = None):
        self.base_dir = base_dir

        if run_dir is None:
            self.run_dir = self._generate_unique_run_dir(base_dir)
        else:
            self.run_dir = run_dir

        self.state_file = self.run_dir / "state.json"

    def _generate_unique_run_dir(self, base_dir: Path) -> Path:
        ts = datetime.now().strftime("%Y-%m-%d_%H%M%S")
        candidate = base_dir / ts

        if not candidate.exists():
            return candidate

        for k in range(1, 1000):
            candidate_k = base_dir / f"{ts}_{k:02d}"
            if not candidate_k.exists():
                return candidate_k

        raise RuntimeError(f"Could not generate a unique run directory under {base_dir}")

    def initialize(self, initial_state: dict):
        self.run_dir.mkdir(parents=True, exist_ok=False)
        with open(self.state_file, "w") as f:
            json.dump(initial_state, f, indent=2)

    def load_state(self) -> dict:
        with open(self.state_file, "r") as f:
            return json.load(f)

    def save_state(self, state: dict):
        with open(self.state_file, "w") as f:
            json.dump(state, f, indent=2)

    def create_layout(self):
        (self.run_dir / "inputs" / "crystal").mkdir(parents=True, exist_ok=True)
        (self.run_dir / "inputs" / "monomer").mkdir(parents=True, exist_ok=True)
        (self.run_dir / "jobs" / "crystal").mkdir(parents=True, exist_ok=True)
        (self.run_dir / "jobs" / "monomer").mkdir(parents=True, exist_ok=True)
        (self.run_dir / "results").mkdir(exist_ok=True)
        (self.run_dir / "logs").mkdir(exist_ok=True)

    def stage_cif_for_crystal(self, source_cif: Path) -> Path:
        dest = self.run_dir / "inputs" / "crystal" / source_cif.name
        copy2(source_cif, dest)
        return dest

    def write_crystal_slurm_script(
        self,
        qe_input_rel: str,
        job_name: str,
        walltime: str = "2:00:00",
        ntasks: int = 8,
        nodes: int = 1,
        mem_per_cpu: str = "4G",
        qe_command: str = "pw.x",
    ) -> Path:
        """
        Write a SLURM script for the crystal QE calculation.

        Defaults requested:
          - #SBATCH --nodes=1
          - #SBATCH --mem-per-cpu=4G
          - #SBATCH --time=2:00:00
        """
        qe_input_path = self.run_dir / qe_input_rel
        if not qe_input_path.exists():
            raise RuntimeError(f"QE input file not found for SLURM generation: {qe_input_path}")

        script_path = self.run_dir / "jobs" / "crystal" / f"{job_name}.slurm"
        slurm_out_path = (script_path.parent / f"{job_name}.slurm.out").resolve()
        input_dir = qe_input_path.parent.resolve()

        script_text = dedent(
            f"""\
            #!/bin/bash
            #SBATCH --job-name={job_name}
            #SBATCH --output={slurm_out_path}
            #SBATCH --nodes={nodes}
            #SBATCH --ntasks={ntasks}
            #SBATCH --mem-per-cpu={mem_per_cpu}
            #SBATCH --time={walltime}

            set -e

            module load medsci
            module load quantum-espresso/7.1

            infile=$(basename "{qe_input_path.name}" .in)
            indir="{input_dir}"
            workdir=/hpfs/userws/$USER/workdir/$SLURM_JOBID

            mkdir -p "$workdir" && cd "$workdir" && echo "$workdir"
            cp -r "$indir/$infile.in" "$workdir"

            srun {qe_command} -i "$infile.in" > "$infile.out"
            cp "$infile.out" "$indir"
            """
        )

        script_path.write_text(script_text)
        return script_path